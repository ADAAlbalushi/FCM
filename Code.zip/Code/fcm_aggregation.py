"""
FCM Construction, Augmentation, and Aggregation
==============================================

This script implements the full workflow for:
- Individual heterogeneity analysis
- Concept filtering (inclusion/exclusion rules)
- **FCM dimension standardization via augmentation**
- Conditional aggregation of multiple Fuzzy Cognitive Maps (FCMs)

Augmentation (Step 2.4.1) ensures that all FCMs share the same
concept space before aggregation by:
- Identifying the global concept set
- Adding missing rows/columns
- Filling absent relationships with zeros

Pipeline position:
Step 2 — FCM Construction, Augmentation & Aggregation
"""

import os
import pandas as pd
import numpy as np
from collections import defaultdict

# ==========================================
# 1. Configuration and Constants
# ==========================================

fcm_files = [f"../FCM/Data/EXPFCM{i}.csv" for i in range(1, 9)]

absolute_degree_centrality = {
    "EXPFCM1": 70.5, "EXPFCM2": 45.0, "EXPFCM3": 68.0, "EXPFCM4": 63.0,
    "EXPFCM5": 55.5, "EXPFCM6": 64.0, "EXPFCM7": 87.0, "EXPFCM8": 73.5
}

output_dir = "results"
os.makedirs(output_dir, exist_ok=True)

excluded_concepts = ["C12", "C32"]

# ==========================================
# 2. Load FCMs and Apply Exclusion Rules
# ==========================================

fcm_matrices = {}
global_concepts = set()

for fcm_file in fcm_files:
    if not os.path.exists(fcm_file):
        continue

    df = pd.read_csv(fcm_file, index_col=0)

    # Apply exclusion rules
    df = df.drop(
        index=excluded_concepts,
        columns=excluded_concepts,
        errors="ignore"
    )

    fcm_name = os.path.basename(fcm_file).replace(".csv", "")
    fcm_matrices[fcm_name] = df
    global_concepts.update(df.index)
    global_concepts.update(df.columns)

global_concepts = sorted(global_concepts)

# ==========================================
# 3. Step 2.4.1 — Augmentation (Dimension Standardization)
# ==========================================

augmented_fcms = {}

for fcm_name, df in fcm_matrices.items():
    augmented_df = df.reindex(
        index=global_concepts,
        columns=global_concepts,
        fill_value=0
    )
    augmented_fcms[fcm_name] = augmented_df

# ==========================================
# 4. Aggregation (Conditional Mean)
# ==========================================

aggregated_edges = defaultdict(list)

for df in augmented_fcms.values():
    for src in df.index:
        for tgt in df.columns:
            weight = df.loc[src, tgt]
            if weight != 0:
                aggregated_edges[(src, tgt)].append(weight)

final_data = []

for (src, tgt), weights in aggregated_edges.items():
    final_data.append({
        "Source": src,
        "Target": tgt,
        "Weight": np.mean(weights),
        "Mention_Count": len(weights)
    })

aggregated_fcm_df = pd.DataFrame(final_data)

aggregated_fcm_df.to_csv(
    os.path.join(output_dir, "final_aggregated_fcm.csv"),
    index=False
)

print("FCM augmentation and aggregation complete.")
print(f"Results saved in: {output_dir}")
