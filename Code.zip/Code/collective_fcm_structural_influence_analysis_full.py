
"""
The Collective FCM Model: Structural and Influence Analysis
==========================================================

Step 3 in the analysis pipeline.

Performs:
- Structural analysis of the collective FCM
- Influence/centrality analysis
- Export of results

Converted from Jupyter Notebook.
No analytical logic altered.
"""

from collections import Counter
import pandas as pd

# Final Merge: Importing relationship matrix data from a CSV file

# Reading a csv file using pandas
df = pd.read_csv("../FCM/results/Final Merged FCM.csv", index_col=0)  # Assuming the first column contains row labels

# The matrix will not be printed
# print(df)  # <-- Commented out to avoid printing

# Total number of concepts
total_concepts = len(df.index)

# Total number of connections (considering any non-zero value as a connection)
total_connections = (df != 0).sum().sum()

# Indegree and Outdegree of each concept (considering any non-zero value as a connection)
indegrees = (df != 0).sum(axis=0)
outdegrees = (df != 0).sum(axis=1)

# Centrality: the summation of its outdegree and indegree scores (binary, ignoring the relationship value)
centrality = outdegrees + indegrees

# Degree: the summation of the absolute values of the outdegree and indegree scores
degree = df.abs().sum(axis=0) + df.abs().sum(axis=1)

# Type of concept (driver, ordinary, receiver)
types = []
for i in range(total_concepts):
    if indegrees.iloc[i] == 0:
        types.append("Driver")
    elif outdegrees.iloc[i] == 0:
        types.append("Receiver")
    else:
        types.append("Ordinary")

# Creating a DataFrame to store the results
results_df = pd.DataFrame({
    'Indegree': indegrees,
    'Outdegree': outdegrees,
    'Centrality': centrality,
    'Type': types
})

# Counting the number of Driver, Receiver, and Ordinary concepts
type_counts = Counter(types)

# Print number of concepts and total number of connections
print("Number of Concepts:", total_concepts)
print("Total Number of Connections:", total_connections)

# Printing the number of driver, receiver, and ordinary variables
print("Number of Driver Concepts:", type_counts['Driver'])
print("Number of Receiver Concepts:", type_counts['Receiver'])
print("Number of Ordinary Concepts:", type_counts['Ordinary'])

# Printing the DataFrame with results
print(results_df)


from collections import Counter
import pandas as pd

# Final Merge: Importing relationship matrix data from a CSV file

# Reading a csv file using pandas
df = pd.read_csv("../FCM/Experiments/Final Modified_Matrix-Copy1.csv", index_col=0)  # Assuming the first column contains row labels

# The matrix will not be printed
# print(df)  # <-- Commented out to avoid printing

# Total number of concepts
total_concepts = len(df.index)

# Total number of connections (considering any non-zero value as a connection)
total_connections = (df != 0).sum().sum()

# Indegree and Outdegree of each concept (considering any non-zero value as a connection)
indegrees = (df != 0).sum(axis=0)
outdegrees = (df != 0).sum(axis=1)

# Centrality: the summation of its outdegree and indegree scores (binary, ignoring the relationship value)
centrality = outdegrees + indegrees

# Degree: the summation of the absolute values of the outdegree and indegree scores
degree = df.abs().sum(axis=0) + df.abs().sum(axis=1)

# Type of concept (driver, ordinary, receiver)
types = []
for i in range(total_concepts):
    if indegrees.iloc[i] == 0:
        types.append("Driver")
    elif outdegrees.iloc[i] == 0:
        types.append("Receiver")
    else:
        types.append("Ordinary")

# Creating a DataFrame to store the results
results_df = pd.DataFrame({
    'Indegree': indegrees,
    'Outdegree': outdegrees,
    'Centrality': centrality,
    'Type': types
})

# Counting the number of Driver, Receiver, and Ordinary concepts
type_counts = Counter(types)

# Print number of concepts and total number of connections
print("Number of Concepts:", total_concepts)
print("Total Number of Connections:", total_connections)

# Printing the number of driver, receiver, and ordinary variables
print("Number of Driver Concepts:", type_counts['Driver'])
print("Number of Receiver Concepts:", type_counts['Receiver'])
print("Number of Ordinary Concepts:", type_counts['Ordinary'])

# Printing the DataFrame with results
print(results_df)


# Create a DataFrame of concepts with ID, label, and centrality
concepts_df = pd.DataFrame({
    'Concept ID': list(centrality.keys()),
    'Label': [concept_labels.get(node, node) for node in centrality.keys()],
    'Centrality': list(centrality.values())
})

# Sort by centrality (optional)
concepts_df.sort_values(by='Centrality', ascending=False, inplace=True)

# Save to CSV
concepts_output_path = os.path.join(output_folder, "Concepts_with_Centrality.csv")
concepts_df.to_csv(concepts_output_path, index=False)

print(f"Concepts CSV saved to: {concepts_output_path}")


import os
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
import seaborn as sns   # ← NEW
import numpy as np

# ---------------------------------------------
# Apply Seaborn Style
# ---------------------------------------------
sns.set_theme(
    style="white",       # clean, minimal, no distracting grid
    context="talk",      # larger fonts appropriate for papers
    font_scale=1.2       # slightly larger labels
)

# Load the merged matrix from the final CSV file
final_merged_df = pd.read_csv("../FCM/Experiments/Final Modified_Matrix-Copy1.csv", index_col=0)

# Load the concept ID to label mapping and types
concept_labels_df = pd.read_csv("../FCM/Data/Concept labels.csv")
concept_labels = dict(zip(concept_labels_df['Concept ID'], concept_labels_df['Label']))
concept_types = dict(zip(concept_labels_df['Concept ID'], concept_labels_df['Type']))

# Define colors for node types
type_colors = {
    "Natural": "#a8a6a3",
    "Anthropogenic": "#d6c165"
}

# Create graph
G = nx.DiGraph()

# Add edges
for concept1 in final_merged_df.index:
    for concept2 in final_merged_df.columns:
        weight = final_merged_df.at[concept1, concept2]
        if weight != 0:
            G.add_edge(concept1, concept2, weight=weight)

# Centrality measure
centrality = dict(G.degree())

# Graph layout
pos = nx.spring_layout(G, k=1.2, seed=42)

# Manual adjustments
if 'C46' in pos: pos['C46'][0] += 0.1
if 'C27' in pos: pos['C27'][0] -= 0.1
if 'C47' in pos:
    pos['C47'][1] += 0.3
    pos['C47'][0] += 0.2
if 'C43' in pos: pos['C43'][0] += 0.5
if 'C20' in pos:
    pos['C20'][1] += 0.1
    pos['C20'][0] += 0.1
if 'C28' in pos: pos['C28'][1] += 0.05
if 'C30' in pos: pos['C30'][1] += 0.15
if 'C1' in pos: pos['C1'][1] += 0.15
if 'C40' in pos: pos['C40'][0] = 0
if 'C36' in pos:
    pos['C36'][0] -= 0.05
    pos['C36'][1] += 0.23
if 'C39' in pos: pos['C39'][0] += 0.15
if 'C4' in pos: pos['C4'][1] += 0.05

# Edge colors by sign
edge_colors = ['blue' if data['weight'] > 0 else 'red' for _, _, data in G.edges(data=True)]

# Edge strength thresholds
low_threshold = 0.3
medium_threshold = 0.7

# Edge widths
edge_widths = []
for _, _, data in G.edges(data=True):
    abs_weight = abs(data['weight'])
    if abs_weight <= low_threshold:
        edge_widths.append(0.5)
    elif abs_weight <= medium_threshold:
        edge_widths.append(1.5)
    else:
        edge_widths.append(3)

# Plot
plt.figure(figsize=(30, 24))

nx.draw_networkx_edges(
    G, pos,
    width=edge_widths,
    alpha=0.95,
    edge_color=edge_colors,
    arrows=True,
    arrowsize=40,
    arrowstyle='-|>',
    connectionstyle='arc3,rad=0.2',
    node_size=[3000 + 2000 * centrality[node] for node in G.nodes()]
)

# Node sizes
node_sizes = [3000 + 2000 * centrality[node] for node in G.nodes()]

# Node colors via type
node_colors = [
    type_colors.get(concept_types.get(node, "Anthropogenic"), "#ADEAEA")
    for node in G.nodes()
]

# Draw nodes
nx.draw_networkx_nodes(
    G, pos,
    node_size=node_sizes,
    alpha=0.97,
    edgecolors='black',
    linewidths=1.3,
    node_color=node_colors
)



# Node labels – enhanced visibility
nx.draw_networkx_labels(
    G, pos,
    labels=node_labels,
    font_size=20,                  # increased font size
    font_family='sans-serif',
    font_weight='bold',            # bold font for better readability
    bbox=dict(
        facecolor='white', 
        alpha=0.85,                # slightly more opaque
        edgecolor='black',         # thin black border
        boxstyle="round,pad=0.3"  # slightly larger padding
    )
)


# ---- Legend (unchanged logic, but fits Seaborn style) ----
def area_to_markersize(area):
    return (area ** 0.5)

low_centrality = 1
medium_centrality = 7
high_centrality = 14

low_node_size = 3000 + 2000 * low_centrality
medium_node_size = 3000 + 2000 * medium_centrality
high_node_size = 3000 + 2000 * high_centrality

low_marker_size = area_to_markersize(low_node_size)
medium_marker_size = area_to_markersize(medium_node_size)
high_marker_size = area_to_markersize(high_node_size)

legend_elements = [
    plt.Line2D([0], [0], color='blue', lw=3, label='Positive Relationship', alpha=0.8),
    plt.Line2D([0], [0], color='red', lw=3, label='Negative Relationship', alpha=0.8),
    plt.Line2D([0], [0], color='gray', lw=0.5, label='Low Strength Relationship'),
    plt.Line2D([0], [0], color='gray', lw=1.5, label='Medium Strength Relationship'),
    plt.Line2D([0], [0], color='gray', lw=3, label='Strong Strength Relationship'),
    plt.Line2D([0], [0], marker='o', color='w', label='Natural',
               markerfacecolor=type_colors["Natural"], markeredgecolor='black', markersize=low_marker_size),
    plt.Line2D([0], [0], marker='o', color='w', label='Anthropogenic',
               markerfacecolor=type_colors["Anthropogenic"], markeredgecolor='black', markersize=low_marker_size),
    plt.Line2D([0], [0], marker='o', color='w', label='Low Centrality', 
               markerfacecolor='white', markeredgecolor='black', markersize=low_marker_size),
    plt.Line2D([0], [0], marker='o', color='w', label='Medium Centrality', 
               markerfacecolor='white', markeredgecolor='black', markersize=medium_marker_size),
    plt.Line2D([0], [0], marker='o', color='w', label='High Centrality', 
               markerfacecolor='white', markeredgecolor='black', markersize=high_marker_size)
]

plt.legend(
    handles=legend_elements,
    loc='lower left',
    bbox_to_anchor=(0.0, 0.89),
    fontsize=20,
    borderpad=3.5,
    labelspacing=1.5,
    handletextpad=3.7,
    borderaxespad=1.5,
    ncol=1,
    frameon=True,
    fancybox=True,
    framealpha=0.8
)


plt.title("", fontsize=28)
plt.axis('off')

# Save figure as PDF
output_folder = "../FCM/results"
os.makedirs(output_folder, exist_ok=True)
output_file = os.path.join(output_folder, "Operational_FCM.pdf")  # <- changed to .pdf
plt.savefig(output_file, bbox_inches='tight', facecolor='white')  # dpi can be omitted for PDF

plt.show()


import pandas as pd
import networkx as nx
import os

# --- FILE PATH CONFIGURATION ---
FINAL_MATRIX_FILE = "../FCM/Experiments/Final Modified_Matrix-Copy1.csv"
CONCEPT_LABELS_FILE = "../FCM/Data/Concept labels.csv"
OUTPUT_FILE = "FCM_Feedback_Loop_Analysis_Geometric_Mean.csv"

# ---------------------------------------------------------------------
# 1. Data Loading and Concept Mapping
# ---------------------------------------------------------------------

try:
    final_merged_df = pd.read_csv(FINAL_MATRIX_FILE, index_col=0)
except FileNotFoundError:
    FINAL_MATRIX_FILE = "Final Modified_Matrix-Copy1.csv"
    final_merged_df = pd.read_csv(FINAL_MATRIX_FILE, index_col=0)
    print(f"Using matrix file: {FINAL_MATRIX_FILE}")

concept_labels = {}
try:
    concept_labels_df = pd.read_csv(CONCEPT_LABELS_FILE)
    concept_labels = dict(zip(concept_labels_df['Concept ID'], concept_labels_df['Label']))
    print(f"Successfully loaded concept labels from: {CONCEPT_LABELS_FILE}")
except FileNotFoundError:
    print(f"Warning: Concept labels file not found. Using IDs.")
    concept_labels = {idx: idx for idx in final_merged_df.index}

# ---------------------------------------------------------------------
# 2. Graph Construction and Cycle Identification
# ---------------------------------------------------------------------

G = nx.DiGraph()
for source in final_merged_df.index:
    for target in final_merged_df.columns:
        weight = final_merged_df.loc[source, target]
        if weight != 0:
            G.add_edge(source, target, weight=weight)

all_cycles = list(nx.simple_cycles(G))
print(f"Total cycles identified: {len(all_cycles)}")

# ---------------------------------------------------------------------
# 3. Loop Analysis (Geometric Mean Strength and Polarity)
# ---------------------------------------------------------------------

loop_analysis = []

for cycle in all_cycles:
    raw_product = 1.0
    num_negative_edges = 0
    cycle_length = len(cycle)

    # Iterate through edges in the cycle
    for i in range(cycle_length):
        source = cycle[i]
        target = cycle[(i + 1) % cycle_length]
        weight = G.get_edge_data(source, target)['weight']
        
        # Multiply absolute weights for the product
        raw_product *= abs(weight)
        
        # Count negative edges for polarity
        if weight < 0:
            num_negative_edges += 1
            
    # CALCULATE GEOMETRIC MEAN STRENGTH
    # Formula: (Product of absolute weights) ^ (1 / n)
    geometric_strength = raw_product ** (1 / cycle_length)
        
    # Determine polarity: R if even number of negative edges, B otherwise
    polarity = 'R' if num_negative_edges % 2 == 0 else 'B'
    
    # Format labels
    path_id = " -> ".join(cycle) + " -> " + cycle[0]
    labeled_path = " -> ".join([concept_labels.get(c, c) for c in cycle]) + " -> " + concept_labels.get(cycle[0], cycle[0])
    
    loop_analysis.append({
        'Path_ID': path_id,
        'Path_Labelled': labeled_path,
        'Length': cycle_length,
        'Raw_Product': round(raw_product, 6),
        'Strength': round(geometric_strength, 4),  # Geometric Mean
        'Polarity': polarity,
        'Neg_Edges': num_negative_edges
    })

# Sort by Geometric Strength descending
loops_df = pd.DataFrame(loop_analysis).sort_values(by='Strength', ascending=False).reset_index(drop=True)

# ---------------------------------------------------------------------
# 4. Output Results
# ---------------------------------------------------------------------

loops_df.to_csv(OUTPUT_FILE, index=False)
print(f"\nAnalysis complete. Results saved to: {OUTPUT_FILE}")

# Quick summary
print(f"\nTop 10 Strongest Loops (Geometric Mean Strength):")
print(loops_df[['Path_Labelled', 'Strength', 'Polarity']].head(10))

import pandas as pd
import networkx as nx
import os

# ---------------------------------------------------------------------
# FILE PATH CONFIGURATION
# ---------------------------------------------------------------------

FINAL_MATRIX_FILE = "../FCM/Experiments/Final Modified_Matrix-Copy1.csv"
CONCEPT_LABELS_FILE = "../FCM/Data/Concept labels.csv"
OUTPUT_FILE = "FCM_Feedback_Loop_Analysis_Labeled_Final.csv"

# ---------------------------------------------------------------------
# 1. DATA LOADING AND CONCEPT MAPPING
# ---------------------------------------------------------------------

# Load the final merged matrix
try:
    final_merged_df = pd.read_csv(FINAL_MATRIX_FILE, index_col=0)
except FileNotFoundError:
    FINAL_MATRIX_FILE = "Final Modified_Matrix-Copy1.csv"
    final_merged_df = pd.read_csv(FINAL_MATRIX_FILE, index_col=0)
    print(f"Using matrix file: {FINAL_MATRIX_FILE}")

# Load concept labels
try:
    concept_labels_df = pd.read_csv(CONCEPT_LABELS_FILE)
    concept_labels = dict(
        zip(concept_labels_df['Concept ID'],
            concept_labels_df['Label'])
    )
    print(f"Successfully loaded concept labels from: {CONCEPT_LABELS_FILE}")
except FileNotFoundError:
    print(f"Warning: Concept labels file not found at {CONCEPT_LABELS_FILE}.")
    concept_labels = {idx: idx for idx in final_merged_df.index}
    print("Using Concept IDs for labeling.")

# ---------------------------------------------------------------------
# 2. GRAPH CONSTRUCTION AND CYCLE IDENTIFICATION
# ---------------------------------------------------------------------

G = nx.DiGraph()

for source in final_merged_df.index:
    for target in final_merged_df.columns:
        weight = final_merged_df.loc[source, target]
        if weight != 0:
            G.add_edge(source, target, weight=weight)

all_cycles = list(nx.simple_cycles(G))
print(f"Total cycles identified: {len(all_cycles)}")

# ---------------------------------------------------------------------
# 3. LOOP ANALYSIS (CASTRO 2022: AVERAGE ABSOLUTE WEIGHT)
# ---------------------------------------------------------------------

loop_analysis = []

for cycle in all_cycles:
    sum_absolute_weights = 0.0
    num_negative_edges = 0
    cycle_length = len(cycle)

    signed_edges = []
    signed_edges_labeled = []

    # Iterate through edges in the cycle
    for i in range(cycle_length):
        source = cycle[i]
        target = cycle[(i + 1) % cycle_length]
        weight = G.get_edge_data(source, target)['weight']

        # Castro (2022): Sum absolute weights
        sum_absolute_weights += abs(weight)

        # Count negative edges for polarity
        if weight < 0:
            num_negative_edges += 1

        # Store signed edge representation
        signed_edges.append(
            f"{source} -({weight:+.3f})-> {target}"
        )
        signed_edges_labeled.append(
            f"{concept_labels.get(source, source)} "
            f"-({weight:+.3f})-> "
            f"{concept_labels.get(target, target)}"
        )

    # Average loop strength (w_f)
    average_strength = sum_absolute_weights / cycle_length

    # Polarity (multiplicative logic)
    polarity = 'R' if num_negative_edges % 2 == 0 else 'B'

    loop_analysis.append({
        'Path_ID_Signed': " | ".join(signed_edges),
        'Path_Labelled_Signed': " | ".join(signed_edges_labeled),
        'Length': cycle_length,
        'Sum_Abs_Weights': round(sum_absolute_weights, 4),
        'Strength_wf_Average': round(average_strength, 4),
        'Polarity': polarity,
        'Negative_Edges': num_negative_edges
    })

# Convert to DataFrame and sort
loops_df = (
    pd.DataFrame(loop_analysis)
    .sort_values(by='Strength_wf_Average', ascending=False)
    .reset_index(drop=True)
)

# ---------------------------------------------------------------------
# 4. OUTPUT RESULTS
# ---------------------------------------------------------------------

loops_df.to_csv(OUTPUT_FILE, index=False)
print(f"\nAnalysis complete. Results saved to: {OUTPUT_FILE}")

# Summary output
N = 10
print(f"\nTop {N} Strongest Loops (Castro 2022 – Average Strength):")
print(
    loops_df[
        ['Path_Labelled_Signed',
         'Strength_wf_Average',
         'Polarity']
    ].head(N)
)

print("\nOverall Polarity Summary:")
print(loops_df['Polarity'].value_counts())


import pandas as pd
import networkx as nx

# ---------------------------------------------------------------------
# FILE PATH CONFIGURATION
# ---------------------------------------------------------------------

FINAL_MATRIX_FILE = "../FCM/Experiments/Final Modified_Matrix-Copy1.csv"
CONCEPT_LABELS_FILE = "../FCM/Data/Concept labels.csv"
OUTPUT_FILE = "FCM_Feedback_Loop_Analysis_Combined_Metrics_Verified.csv"

# ---------------------------------------------------------------------
# 1. DATA LOADING AND CONCEPT MAPPING
# ---------------------------------------------------------------------

try:
    final_merged_df = pd.read_csv(FINAL_MATRIX_FILE, index_col=0)
except FileNotFoundError:
    FINAL_MATRIX_FILE = "Final Modified_Matrix-Copy1.csv"
    final_merged_df = pd.read_csv(FINAL_MATRIX_FILE, index_col=0)
    print(f"Using matrix file: {FINAL_MATRIX_FILE}")

try:
    concept_labels_df = pd.read_csv(CONCEPT_LABELS_FILE)
    concept_labels = dict(
        zip(concept_labels_df['Concept ID'],
            concept_labels_df['Label'])
    )
    print(f"Successfully loaded concept labels from: {CONCEPT_LABELS_FILE}")
except FileNotFoundError:
    print("Warning: Concept labels file not found. Using Concept IDs.")
    concept_labels = {idx: idx for idx in final_merged_df.index}

# ---------------------------------------------------------------------
# 2. GRAPH CONSTRUCTION AND CYCLE IDENTIFICATION
# ---------------------------------------------------------------------

G = nx.DiGraph()

for source in final_merged_df.index:
    for target in final_merged_df.columns:
        weight = final_merged_df.loc[source, target]
        if weight != 0:
            G.add_edge(source, target, weight=weight)

all_cycles = list(nx.simple_cycles(G))
print(f"Total feedback loops identified: {len(all_cycles)}")

# ---------------------------------------------------------------------
# 3. LOOP ANALYSIS (CASTRO + GEOMETRIC MEAN)
# ---------------------------------------------------------------------

loop_analysis = []

for cycle in all_cycles:
    cycle_length = len(cycle)

    sum_abs_weights = 0.0
    product_abs_weights = 1.0
    num_negative_edges = 0

    signed_edges = []
    signed_edges_labeled = []

    for i in range(cycle_length):
        source = cycle[i]
        target = cycle[(i + 1) % cycle_length]
        weight = G.get_edge_data(source, target)['weight']

        # --- Strength components ---
        abs_weight = abs(weight)
        sum_abs_weights += abs_weight
        product_abs_weights *= abs_weight

        # --- Polarity ---
        if weight < 0:
            num_negative_edges += 1

        # --- Signed path ---
        signed_edges.append(f"{source} -({weight:+.3f})-> {target}")
        signed_edges_labeled.append(
            f"{concept_labels.get(source, source)} "
            f"-({weight:+.3f})-> "
            f"{concept_labels.get(target, target)}"
        )

    # --- Final metrics ---
    castro_strength = sum_abs_weights / cycle_length
    geometric_strength = product_abs_weights ** (1 / cycle_length)
    polarity = 'R' if num_negative_edges % 2 == 0 else 'B'

    loop_analysis.append({
        'Path_Labelled_Signed': " | ".join(signed_edges_labeled),
        'Length': cycle_length,
        'Negative_Edges': num_negative_edges,
        'Polarity': polarity,
        'Castro_wf_Average': round(castro_strength, 4),
        'Geometric_Mean_Strength': round(geometric_strength, 4)
    })

# ---------------------------------------------------------------------
# 4. OUTPUT
# ---------------------------------------------------------------------

loops_df = (
    pd.DataFrame(loop_analysis)
    .sort_values(by='Geometric_Mean_Strength', ascending=False)
    .reset_index(drop=True)
)

loops_df.to_csv(OUTPUT_FILE, index=False)
print(f"\nVerified combined analysis saved to: {OUTPUT_FILE}")

print("\nTop 10 loops (by geometric mean):")
print(
    loops_df[
        ['Path_Labelled_Signed',
         'Castro_wf_Average',
         'Geometric_Mean_Strength',
         'Polarity']
    ].head(10)
)


# --- Compute raw degree and normalized centrality --- 
degree_dict = dict(G.degree())  # in+out connections count
centrality_dict = nx.degree_centrality(G)  # normalized centrality (0–1)

# Convert to DataFrame
centrality_df = pd.DataFrame({
    "Concept ID": list(centrality_dict.keys()),
    "Centrality": list(centrality_dict.values()),
    "Degree": [degree_dict[node] for node in centrality_dict.keys()],
    "Label": [concept_labels.get(node, node) for node in centrality_dict.keys()]
})

# --- Sort and get Top 20 concepts ---
top_20 = centrality_df.sort_values(by="Centrality", ascending=False).head(20)

print("\nTop 20 Concepts by Centrality:")
print(top_20[["Concept ID", "Label", "Centrality", "Degree"]])

# Extract labels as list
top_20_labels = top_20["Label"].tolist()
print("\nList of Top 20 Concept Labels:")
print(top_20_labels)

# --- Calculate % contribution of Top 20 centrality ---
total_centrality = centrality_df["Centrality"].sum()
top_20_centrality = top_20["Centrality"].sum()
percentage_contribution = (top_20_centrality / total_centrality) * 100

print(f"\nTop 20 concepts account for {percentage_contribution:.2f}% of the total centrality.")

# ---------------------------------------------------------------------
# Influence Table (Direct, Indirect, Total on OUV) for ALL concepts
# ---------------------------------------------------------------------
OUV_node = 'C1'  # Adjust if OUV has a different Concept ID

influence_data = []

for node in G.nodes():
    label = concept_labels.get(node, node)
    ctype = concept_types.get(node, "Anthropogenic")

    # --- Direct Influence ---
    direct_influence = G[node][OUV_node]['weight'] if G.has_edge(node, OUV_node) else 0

    # --- Indirect Influence (all paths >1 step) ---
    indirect_influence = 0
    for path in nx.all_simple_paths(G, source=node, target=OUV_node):  # all paths
        if len(path) > 2:  # only indirect
            path_weight = 1
            for i in range(len(path) - 1):
                path_weight *= G[path[i]][path[i + 1]]['weight']
            indirect_influence += path_weight

    # --- Total Influence ---
    total_influence = direct_influence + indirect_influence

    influence_data.append({
        "Concept ID": node,
        "Label": label,
        "Type": ctype,
        "Direct Influence on OUV": direct_influence,
        "Indirect Influence on OUV": indirect_influence,
        "Total Influence on OUV": total_influence
    })

# Convert to DataFrame
influence_df = pd.DataFrame(influence_data)

# Sort by strongest total influence
influence_df = influence_df.sort_values(by="Total Influence on OUV", ascending=False)

# Save results
output_table_file = os.path.join(output_folder, "Concept_Influences_on_OUV.csv")
influence_df.to_csv(output_table_file, index=False)

print("✅ Influence table saved at:", output_table_file)
print(influence_df.head(len(influence_df)))  # print all rows

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# -----------------------------------
# Prepare data (your original transformations)
# -----------------------------------
plot_df = influence_df[influence_df['Concept ID'] != 'C1'].copy()

# Map type to color
type_colors = {'Natural': '#a8a6a3', 'Anthropogenic': '#d6c165'}
plot_df['Color'] = plot_df['Type'].map(type_colors)

# Positive and negative influence
plot_df['Positive Influence'] = plot_df['Total Influence on OUV'].apply(lambda x: x if x > 0 else 0)
plot_df['Negative Influence'] = plot_df['Total Influence on OUV'].apply(lambda x: x if x < 0 else 0)

# Top 20 centrality concepts
top20_ids = [
    "C21", "C3", "C40", "C7", "C8", "C39", "C15", "C23", "C2", "C36",
    "C28", "C47", "C6", "C37", "C38", "C46", "C20", "C49", "C25"
]
plot_df['Top20'] = plot_df['Concept ID'].isin(top20_ids)


# -----------------------------------
# Seaborn horizontal bar plot with smaller y-axis labels
# -----------------------------------
sns.set_theme(style="whitegrid", context="talk", font_scale=1.2)

plt.figure(figsize=(12,10))

# Positive influence
sns.barplot(
    x='Positive Influence',
    y='Label',
    data=plot_df,
    palette=plot_df['Color'],
    edgecolor=['purple' if top else 'white' for top in plot_df['Top20']],
    linewidth=1.5
)

# Negative influence (overlay)
sns.barplot(
    x='Negative Influence',
    y='Label',
    data=plot_df,
    palette=plot_df['Color'],
    edgecolor=['purple' if top else 'white' for top in plot_df['Top20']],
    linewidth=1.5
)

plt.xlabel("Influence on OUV", fontsize=14)
plt.ylabel("Concepts", fontsize=14)
plt.title("", fontsize=16, weight='bold')

# Reduce y-axis label size
plt.yticks(fontsize=10)   # <-- smaller font for concept names

# Legend
from matplotlib.patches import Patch
legend_elements = [
    Patch(facecolor='#a8a6a3', label='Natural'),
    Patch(facecolor='#d6c165', label='Anthropogenic'),
    Patch(facecolor='none', edgecolor='purple', linewidth=1.5, label='Top 20 Centrality')
]
plt.legend(handles=legend_elements, title="", fontsize=10, title_fontsize=12, loc='lower right')


plt.tight_layout()

# Save as PDF for high resolution
plt.savefig("Influence_on_OUV.png", bbox_inches='tight', facecolor='white')

plt.show()


